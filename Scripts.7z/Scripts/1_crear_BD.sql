--
-- PostgreSQL database dump
--

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-02 11:32:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5089 (class 1262 OID 25295)
-- Name: data_model_with_custom_orders; Type: DATABASE; Schema: -; Owner: -
--

-- Si no ha creado la base de datos descomentar la siguiente linea
-- CREATE DATABASE data_model_with_custom_orders WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Mexico.1252';

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET search_path = public;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 25297)
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    phone_number character varying(20),
    date_joined date,
    address character varying(255)
);


--
-- TOC entry 219 (class 1259 OID 25296)
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5090 (class 0 OID 0)
-- Dependencies: 219
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- TOC entry 230 (class 1259 OID 25410)
-- Name: daily_inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_inventory (
    date_of_inventory date CONSTRAINT daily_inventory_levels_date_of_inventory_not_null NOT NULL,
    product_id integer CONSTRAINT daily_inventory_levels_product_id_not_null NOT NULL,
    level integer CONSTRAINT daily_inventory_levels_level_not_null NOT NULL,
    CONSTRAINT chk_inventory_level CHECK ((level >= 0))
);


--
-- TOC entry 225 (class 1259 OID 25335)
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    date_of_order date NOT NULL,
    order_status character varying(50) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    shipping_address character varying(255) NOT NULL,
    CONSTRAINT chk_order_status CHECK (((order_status)::text = ANY ((ARRAY['Pendiente'::character varying, 'Procesando'::character varying, 'Enviado'::character varying, 'Entregado'::character varying, 'Cancelado'::character varying])::text[]))),
    CONSTRAINT chk_total_amount CHECK ((total_amount >= (0)::numeric))
);


--
-- TOC entry 224 (class 1259 OID 25334)
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5091 (class 0 OID 0)
-- Dependencies: 224
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- TOC entry 221 (class 1259 OID 25311)
-- Name: product_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_types (
    product_type_code character varying(10) NOT NULL,
    parent_product_type_code character varying(10),
    product_type_name character varying(100) CONSTRAINT product_types_product_type_description_not_null NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 25355)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    product_type_code character varying(10) NOT NULL,
    supplier_id integer,
    product_name character varying(100) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    product_description character varying(500),
    reorder_level integer NOT NULL,
    reorder_quantity integer NOT NULL,
    other_details character varying(255),
    weight_kg numeric(8,2),
    date_added date DEFAULT CURRENT_DATE NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    quantity integer CONSTRAINT "products_Quanity_not_null" NOT NULL,
    image_url character varying(500),
    CONSTRAINT chk_reorder_level CHECK ((reorder_level >= 0)),
    CONSTRAINT chk_reorder_quantity CHECK ((reorder_quantity > 0)),
    CONSTRAINT chk_unit_price CHECK ((unit_price > (0)::numeric))
);


--
-- TOC entry 229 (class 1259 OID 25387)
-- Name: products_in_the_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products_in_the_order (
    order_item_id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    product_quantity integer NOT NULL,
    item_unit_price double precision,
    CONSTRAINT chk_product_quantity CHECK ((product_quantity > 0))
);


--
-- TOC entry 228 (class 1259 OID 25386)
-- Name: products_in_the_order_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_in_the_order_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5092 (class 0 OID 0)
-- Dependencies: 228
-- Name: products_in_the_order_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_in_the_order_order_item_id_seq OWNED BY public.products_in_the_order.order_item_id;


--
-- TOC entry 226 (class 1259 OID 25354)
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5093 (class 0 OID 0)
-- Dependencies: 226
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- TOC entry 223 (class 1259 OID 25324)
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    supplier_id integer NOT NULL,
    supplier_name character varying(200) NOT NULL,
    contact_name character varying(100),
    phone character varying(20),
    address character varying(255),
    email character varying(255)
);


--
-- TOC entry 222 (class 1259 OID 25323)
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5094 (class 0 OID 0)
-- Dependencies: 222
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_supplier_id_seq OWNED BY public.suppliers.supplier_id;


--
-- TOC entry 4886 (class 2604 OID 25300)
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- TOC entry 4888 (class 2604 OID 25338)
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- TOC entry 4889 (class 2604 OID 25358)
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- TOC entry 4892 (class 2604 OID 25390)
-- Name: products_in_the_order order_item_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_in_the_order ALTER COLUMN order_item_id SET DEFAULT nextval('public.products_in_the_order_order_item_id_seq'::regclass);


--
-- TOC entry 4887 (class 2604 OID 33634)
-- Name: suppliers supplier_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplier_id SET DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass);


--
-- TOC entry 4901 (class 2606 OID 25310)
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- TOC entry 4903 (class 2606 OID 25308)
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4917 (class 2606 OID 25418)
-- Name: daily_inventory daily_inventory_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_inventory
    ADD CONSTRAINT daily_inventory_levels_pkey PRIMARY KEY (date_of_inventory, product_id);


--
-- TOC entry 4909 (class 2606 OID 25348)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- TOC entry 4905 (class 2606 OID 25317)
-- Name: product_types product_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_pkey PRIMARY KEY (product_type_code);


--
-- TOC entry 4913 (class 2606 OID 25397)
-- Name: products_in_the_order products_in_the_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_in_the_order
    ADD CONSTRAINT products_in_the_order_pkey PRIMARY KEY (order_item_id);


--
-- TOC entry 4911 (class 2606 OID 25375)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- TOC entry 4907 (class 2606 OID 33636)
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- TOC entry 4915 (class 2606 OID 25399)
-- Name: products_in_the_order uq_order_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_in_the_order
    ADD CONSTRAINT uq_order_product UNIQUE (order_id, product_id);


--
-- TOC entry 4924 (class 2606 OID 25419)
-- Name: daily_inventory daily_inventory_levels_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_inventory
    ADD CONSTRAINT daily_inventory_levels_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- TOC entry 4919 (class 2606 OID 25349)
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- TOC entry 4918 (class 2606 OID 25318)
-- Name: product_types product_types_parent_product_type_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_parent_product_type_code_fkey FOREIGN KEY (parent_product_type_code) REFERENCES public.product_types(product_type_code);


--
-- TOC entry 4922 (class 2606 OID 25400)
-- Name: products_in_the_order products_in_the_order_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_in_the_order
    ADD CONSTRAINT products_in_the_order_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- TOC entry 4923 (class 2606 OID 25405)
-- Name: products_in_the_order products_in_the_order_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_in_the_order
    ADD CONSTRAINT products_in_the_order_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- TOC entry 4920 (class 2606 OID 25376)
-- Name: products products_product_type_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_type_code_fkey FOREIGN KEY (product_type_code) REFERENCES public.product_types(product_type_code);


--
-- TOC entry 4921 (class 2606 OID 33638)
-- Name: products products_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


-- Completed on 2025-12-02 11:32:57

--
-- PostgreSQL database dump complete
--
