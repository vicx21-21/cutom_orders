-- Categorías de Nivel Superior (Padre = NULL)
INSERT INTO product_types (product_type_code, product_type_name, parent_product_type_code) VALUES
('ALIM', 'Alimentos y Comida', NULL),
('BEB', 'Bebidas', NULL),
('HOGAR', 'Productos de Hogar', NULL),
('PEREC', 'Alimentos Perecederos', NULL),
('FRESCO', 'Frutas y Vegetales Frescos', NULL);


-- Subcategorías (Apuntan a un padre)
INSERT INTO product_types (product_type_code, product_type_name, parent_product_type_code) VALUES 
('SNACKS', 'Botanas y Snacks', 'ALIM'), 
('ABARR', 'Abarrotes Secos', 'ALIM'), 
('LACT', 'Lácteos y Refrigerados', 'ALIM'), 
('BEB_F', 'Bebidas Frías (Refrescos, Agua)', 'BEB'), 
('BEB_C', 'Bebidas Calientes (Café, Té)', 'BEB'), 
('LIMP', 'Limpieza del Hogar', 'HOGAR'), 
('HIG_P', 'Higiene Personal', 'HOGAR'), 
('PAN', 'Panadería y Repostería', 'ALIM'), 
('CERE', 'Cereales y Granos', 'ALIM'), 
('COND', 'Condimentos y Salsas', 'ALIM'), 
('ACEI', 'Aceites y Grasas', 'ALIM'), 
('AZUC', 'Azúcares y Endulzantes', 'ALIM'), 
('ENLA', 'Enlatados y Conservas', 'ALIM'), 
('CONG', 'Alimentos Congelados', 'ALIM'), 
('CARNE', 'Carnes y Pescados', 'ALIM'); 
