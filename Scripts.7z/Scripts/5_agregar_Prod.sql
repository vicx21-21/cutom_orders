INSERT INTO products (
    product_type_code, 
    supplier_id, 
    product_name, 
    unit_price, 
    product_description, 
    reorder_level, 
    reorder_quantity, 
    weight_kg, 
    is_active, 
    quantity, 
    image_url
) VALUES
('SNACKS', 1, 'Sabritas Clásicas 120g', 25.50, 'Bolsa de papas fritas saladas, presentación familiar.', 50, 100, 0.12, TRUE, 150, 'sabritas.jpg'),

('BEB_F', 2, 'Coca-Cola Lata 355ml', 18.00, 'Refresco de cola, lata individual.', 80, 150, 0.38, TRUE, 200, 'coca.jpg'),

('LACT', 3, 'Leche Entera Galón', 85.00, 'Leche fresca de vaca, contenido 3.78L.', 10, 20, 3.85, TRUE, 40, 'lechelala.jpg'),

('BEB_C', 4, 'Café Soluble Nescafé 200g', 120.00, 'Café soluble clásico, frasco de vidrio.', 15, 30, 0.20, TRUE, 30, 'cafenest.jpg'),

('ALIM', 5, 'Pan Blanco Grande', 45.00, 'Pan de caja, ideal para sándwiches. 20 rebanadas.', 20, 40, 0.60, TRUE, 50, 'panbimbo.jpg'), 

('HIG_P', 6, 'Pasta Dental 100ml', 35.50, 'Pasta dental con flúor para protección de caries.', 30, 50, 0.12, TRUE, 75, 'pastacolgate.jpg'),

('SNACKS', 1, 'Doritos Nacho 80g', 23.00, 'Totopos de maíz con sabor a queso nacho.', 60, 120, 0.08, TRUE, 120, 'doritos.jpg'),

('BEB_F', 2, 'Agua Embotellada 1L', 15.00, 'Agua purificada, botella de 1 litro.', 100, 200, 1.05, TRUE, 300, 'aguaepura.jpg'),

('LACT', 3, 'Yogurt Natural 1Kg', 65.00, 'Yogurt natural sin azúcar añadido, presentación familiar.', 15, 30, 1.00, TRUE, 25, 'yogurtlala.jpg'),

('BEB_C', 4, 'Chocolate en Polvo Abuelita 250g', 55.00, 'Chocolate en polvo para preparar bebida caliente.', 25, 50, 0.25, TRUE, 45, 'abuelaenpolvo.jpg'),

('SNACKS', 1, 'Cheetos Puffs Gigantes 90g', 24.50, 'Botana de maíz inflado con sabor a queso.', 55, 110, 0.09, TRUE, 130, 'cheetospuff.jpg'),

('ABARR', 4, 'Atún en Agua Dolores 140g', 19.50, 'Lata de atún aleta amarilla en agua.', 40, 80, 0.16, TRUE, 90, 'atundolores.jpg'),

('ALIM', 5, 'Tortillas de Harina Tía Rosa 300g', 32.00, 'Paquete de tortillas de harina, 10 piezas.', 30, 60, 0.30, TRUE, 65, 'tiarosa.jpg'),

('BEB_F', 2, 'Jugo de Naranja del Valle 1L', 22.00, 'Jugo de naranja pasteurizado, botella de cartón.', 70, 140, 1.05, TRUE, 180, 'jugodelvalle.jpg'),

('BEB_C', 4, 'Té Lipton Sobres 25pz', 40.00, 'Caja de té negro en sobres individuales.', 20, 40, 0.05, TRUE, 35, 'telipton.jpg'),

('LACT', 3, 'Mantequilla sin Sal 90g', 39.00, 'Barra de mantequilla de vaca, sin sal.', 12, 24, 0.09, TRUE, 20, 'mantequilla.jpg'),

('LIMP', 6, 'Detergente Líquido 1L', 78.50, 'Detergente concentrado para ropa de color.', 25, 50, 1.00, TRUE, 55, 'detergente.jpg'),

('HIG_P', 6, 'Jabón de Tocador Palmolive 150g', 19.00, 'Barra de jabón de tocador con extractos naturales.', 35, 70, 0.15, TRUE, 85, 'jabonpalmolive.jpg'),

('ABARR', 5, 'Frijoles Negros La Sierra 400g', 17.50, 'Bolsa de frijoles negros refritos listos para comer.', 45, 90, 0.40, TRUE, 110, 'frijolesnegros.jpg'),

('ALIM', 3, 'Huevo Blanco Docena', 48.00, 'Cartón de 12 huevos blancos frescos.', 15, 30, 0.70, TRUE, 40, 'huevoblanco.jpg');
