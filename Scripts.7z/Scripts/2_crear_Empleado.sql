-- Role: empleado2
DROP ROLE IF EXISTS empleado2;

CREATE ROLE empleado2 WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  NOBYPASSRLS
  ENCRYPTED PASSWORD 'SCRAM-SHA-256$4096:1RCQ8Uq5gEspFPyadTh0WA==$mDAI1o5sEVTT4FQ16aNXyiQfK0QUkHiLsCiit5owVBM=:7rtSZZyYXt/uORFxKEYE1khZts0XOfjcXyV+bqbtduM=';

GRANT USAGE ON SCHEMA public TO empleado2;


GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.customers TO empleado2;


GRANT SELECT,USAGE ON SEQUENCE public.customers_customer_id_seq TO empleado2;


GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.daily_inventory TO empleado2;


GRANT ALL ON TABLE public.orders TO empleado2;


GRANT SELECT,USAGE ON SEQUENCE public.orders_order_id_seq TO empleado2;



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.product_types TO empleado2;



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.products TO empleado2;



GRANT ALL ON TABLE public.products_in_the_order TO empleado2;

GRANT SELECT,USAGE ON SEQUENCE public.products_in_the_order_order_item_id_seq TO empleado2;

GRANT USAGE ON SEQUENCE public.products_product_id_seq TO empleado2;

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.suppliers TO empleado2;

GRANT USAGE ON SEQUENCE public.suppliers_supplier_id_seq TO empleado2;



--

ALTER DEFAULT PRIVILEGES FOR ROLE developer IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO empleado2;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE developer IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO empleado2;
